//
//  navController.m
//  myJRTT
//
//  Created by student5 on 2019/4/27.
//  Copyright © 2019 student5. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "navController.h"
@interface navController ()<UIGestureRecognizerDelegate>
@property (nonatomic , strong)UIPanGestureRecognizer *pan;
@end

@implementation navController

-(void)viewDidLoad {
    [super viewDidLoad];
    //1. add img
    CGRect rect = CGRectMake(0.0f,0.0f,1.0f,1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    UIColor *color = [UIColor colorWithRed:0.83 green:0.24 blue:0.24 alpha:1];
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    
    CGContextFillRect(context, rect);
    
    UIImage *Img = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    _defaultImage = Img;
    
    //code
    //_defaultImage = [self.class createImageWithColor:[UIColor colorWithRed:0.83 green:0.24 blue:0.24 alpha:1]];
    //[self addCustomGesPop];
    
    //2. add 常用手势pop
    //边缘侧滑动画
    id target = self.interactivePopGestureRecognizer.delegate;
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:target action:@selector(handleNavigationTransition:)];
    _pan = pan;
    pan.delegate = self;
    
    [self.view addGestureRecognizer:pan];
    //关闭系统默认的边缘返回动画
    self.interactivePopGestureRecognizer.enabled = NO;
    
}

- (void)startPopGestureRecognizer {
    [self.view addGestureRecognizer:self.pan];
}
- (void)stopPopGestureRecognizer {
    [self.view removeGestureRecognizer:self.pan];
}
/*
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (self.childViewControllers.count >= 1) {
        viewController.hidesBottomBarWhenPushed = YES;
    }
    [super pushViewController:viewController animated:animated];
}

*/
//对微头条进行调整
/*
+ (void)initialize {
    
    [[UINavigationBar appearance] setTranslucent:NO];
    NSMutableDictionary * color = [NSMutableDictionary dictionary];
    color[NSFontAttributeName] = [UIFont systemFontOfSize:16];
    color[NSForegroundColorAttributeName] = [UIColor blackColor];
    [[UINavigationBar appearance] setTitleTextAttributes:color];
    
    // 拿到整个导航控制器的外观
    UIBarButtonItem * item = [UIBarButtonItem appearance];
    NSMutableDictionary * atts = [NSMutableDictionary dictionary];
    atts[NSFontAttributeName] = [UIFont systemFontOfSize:30.0f];
    [item setTitleTextAttributes:atts forState:UIControlStateNormal];
    [[UINavigationBar appearance] setBackgroundImage:[self createImageWithColor:[UIColor colorWithRed:0.83 green:0.24 blue:0.24 alpha:1]] forBarMetrics:UIBarMetricsDefault];
 
 + (UIImage*)createImageWithColor:(UIColor*)color{
 
 CGRect rect = CGRectMake(0.0f,0.0f,1.0f,1.0f);UIGraphicsBeginImageContext(rect.size);
 
 CGContextRef context = UIGraphicsGetCurrentContext();
 CGContextSetFillColorWithColor(context, [color CGColor]);
 
 CGContextFillRect(context, rect);
 UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
 UIGraphicsEndImageContext();
 return theImage;
 }
    
}
*/
@end
