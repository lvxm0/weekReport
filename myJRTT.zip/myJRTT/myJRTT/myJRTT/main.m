//
//  main.m
//  myJRTT
//
//  Created by student5 on 2019/4/27.
//  Copyright © 2019 student5. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
