//
//  HomeVC.h
//  myJRTT
//
//  Created by student5 on 2019/4/27.
//  Copyright © 2019 student5. All rights reserved.
//
//首页控制器
#import <UIKit/UIKit.h>

@interface HomeVC :NSObject//: WMPageController

@end

