//
//  navController.h
//  myJRTT
//
//  Created by student5 on 2019/4/27.
//  Copyright © 2019 student5. All rights reserved.
//
//导航控制器
#ifndef navController_h
#define navController_h
#import <UIKit/UIKit.h>

@interface navController : UINavigationController

@property (nonatomic , strong)UIImage *defaultImage;
- (void)startPopGestureRecognizer;
- (void)stopPopGestureRecognizer;

@end

#endif /* navController_h */
