//
//  SecondViewController.m
//  myJRTT
//
//  Created by student5 on 2019/4/27.
//  Copyright © 2019 student5. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


@end
