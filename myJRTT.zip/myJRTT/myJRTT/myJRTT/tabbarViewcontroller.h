//
//  ttViewcontroller.h
//  myJRTT
//
//  Created by student5 on 2019/4/27.
//  Copyright © 2019 student5. All rights reserved.
//
//下方标签栏的控制器
#ifndef tabbarViewcontroller_h
#define tabbarViewcontroller_h

#import <UIKit/UIKit.h>

@interface tabbarViewcontroller : UITabBarController

@end

#endif /* ttViewcontroller_h */
