//
//  tabbarViewcontroller.m
//  myJRTT
//
//  Created by student5 on 2019/4/27.
//  Copyright © 2019 student5. All rights reserved.
//
#define WIDTH      [UIScreen mainScreen].bounds.size.width
#define HEIGHT     [UIScreen mainScreen].bounds.size.height
#define Item_normal_color [UIColor colorWithRed:0.31 green:0.31 blue:0.31 alpha:1.0f]
#define Item_select_color [UIColor colorWithRed:0.96 green:0.96 blue:0.97 alpha:1]



#import <UIKit/UIKit.h>
#import "tabbarViewcontroller.h"
#import "navController.h"
#import "HomeVC.h"


@interface tabbarViewcontroller ()<UITabBarControllerDelegate>

@property (nonatomic , weak)navController *homeNav;
@property (nonatomic , weak)UIImageView *swappableImageView;


@end

@implementation tabbarViewcontroller

+ (void)initialize {
    [[UITabBar appearance] setTranslucent:NO];
    [UITabBar appearance].barTintColor = [UIColor colorWithRed:0.9f green:0.9f blue:0.9f alpha:1.00f];
    //tab bar元素被选中和未选中的情况
    UITabBarItem * item = [UITabBarItem appearance];
    
    item.titlePositionAdjustment = UIOffsetMake(0, -5);
    NSMutableDictionary * normalAtts = [NSMutableDictionary dictionary];
    normalAtts[NSFontAttributeName] = [UIFont systemFontOfSize:10];
    normalAtts[NSForegroundColorAttributeName] = Item_normal_color;
    [item setTitleTextAttributes:normalAtts forState:UIControlStateNormal];
    
    // 选中状态
    NSMutableDictionary *selectAtts = [NSMutableDictionary dictionary];
    selectAtts[NSFontAttributeName] = [UIFont systemFontOfSize:10];
    selectAtts[NSForegroundColorAttributeName] = Item_select_color;
    [item setTitleTextAttributes:selectAtts forState:UIControlStateSelected];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //给每个tab bar的元素都加一个控制器
    // 首页控制器
    _homeNav = [self addChildViewControllerWithClass:[HomeVC class] imageName:@"homebav_Img" selectedImageName:@"homebav_Img_s" title:@"首页"];
    
    /*
     [self addChildViewControllerWithClass:[HNHomeVC class] imageName:@"video_tabbar_32x32_" selectedImageName:@"video_tabbar_press_32x32_" title:@"西瓜视频"];
    [self addChildViewControllerWithClass:[HNHomeVC class] imageName:@"weitoutiao_tabbar_32x32_" selectedImageName:@"weitoutiao_tabbar_press_32x32_" title:@"微头条"];
    [self addChildViewControllerWithClass:[HNHomeVC class] imageName:@"huoshan_tabbar_32x32_" selectedImageName:@"huoshan_tabbar_press_32x32_" title:@"小视频"];
    */
    self.delegate = self;
    
    
}
// 添加子控制器
- (navController *)addChildViewControllerWithClass:(Class)class
                                                  imageName:(NSString *)imageName
                                          selectedImageName:(NSString *)selectedImageName
                                                      title:(NSString *)title {
    UIViewController *vc = [[class alloc]init];
    navController *nav = [[navController alloc] initWithRootViewController:vc];
    nav.tabBarItem.title = title;
    nav.tabBarItem.image = [[UIImage imageNamed:imageName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    nav.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImageName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    [self addChildViewController:nav];
    return nav;
}

@end
